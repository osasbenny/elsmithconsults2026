<?php
return [
    'smtp_host' => 'mail.elsmithconsulting.com',
    'smtp_port' => 465,
    'smtp_username' => 'info@elsmithconsulting.com',
    'smtp_password' => '$R!e0KzGp02ca]zE',
    'from_email' => 'info@elsmithconsulting.com',
    'from_name' => 'ELSMITH Consulting Website',
    'notification_email' => 'info@elsmithconsulting.com',
    'timezone' => 'Africa/Lagos',
    'app_secret' => '7e8c9b2a1d4f5g6h7j8k9l0m1n2p3q4r', // Generated production secret
    'blocked_dates' => [],
    'storage_dir' => dirname(__DIR__) . '/storage'
];
